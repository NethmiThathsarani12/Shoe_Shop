package lk.ijse.gdse66.spring.Back_End;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
